<?php
/**
*	此文件是流程模块【finpay.付款申请】对应控制器接口文件。
*/ 
class mode_finpayClassAction extends inputAction{
	
	
}	
			