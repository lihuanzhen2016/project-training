function initbodys(){
	form('applydt').readOnly=true;
}