//流程模块【knowtraim.考试培训】下录入页面自定义js页面,初始函数
function initbodys(){
	//js.alert('此模块还未开发完成');
}