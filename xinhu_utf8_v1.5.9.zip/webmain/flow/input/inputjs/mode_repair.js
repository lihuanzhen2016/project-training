//流程模块【repair.维修报修】下录入页面自定义js页面,初始函数
function initbodys(){
	
}