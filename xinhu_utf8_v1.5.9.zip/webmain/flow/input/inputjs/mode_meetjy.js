//流程模块【meetjy.会议纪要】下录入页面自定义js页面,初始函数
function initbodys(){
	
}

//添加完成后处理
function savesuccess(){
	history.back();
}