<?php
header('location:./install/index.php');
?>
